To run the script:

1- Open bash and go to the directory which the zip file is located.
2- Execute "unzip HW2_saydemia.zip"
3- Execute "ls" . Make sure that the directory you are currently in has the following files.
	
 DIR|
	|-- knapsack.cpp
	|-- shopping.cpp
	|-- shopping.txt
	|-- HW2Solution.txt 
	|-- HW2_cpp.sh

4- Execute "chmod 700 HW2_cpp.sh". This gives admin privileges to executable. (can be skipped)
5- Execute "HW2_cpp.sh". (If you skipped step 4, you have to run the script with "sh HW2_cpp.sh")