To run the script:

1- Open bash and go to the directory which the zip file is located.
2- Execute "unzip HW4_saydemia.zip"
3- Execute "ls" . Make sure that the directory you are currently in has the following files.
	
 DIR|
	|-- mst.cpp
	|-- HW4_cpp.sh
	|-- HW4solution.txt
	|-- graph.txt

4- Execute "chmod +x HW4_cpp.sh". This gives admin privileges to executable. (can be skipped)
5- Execute "HW4_cpp.sh". (If you skipped step 4, you have to run the script with "sh HW4_cpp.sh")