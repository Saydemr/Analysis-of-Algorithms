To run the script:

1- Open bash and go to the directory which the zip file is located.
2- Execute "unzip HW6_saydemia.zip"
3- Execute "ls" . Make sure that the directory you are currently in has the following files.
	
 DIR|
	|-- tsp.cpp
	|-- HW6.sh
	|-- tsp_example_0.txt
	|-- tsp_example_1.txt
	|-- tsp_example_2.txt
	|-- tsp_example_3.txt
	|-- tsp_example_4.txt
	|-- tsp_example_5.txt
	|-- tsp_example_0.txt.tour
	|-- tsp_example_1.txt.tour
	|-- tsp_example_2.txt.tour
	|-- tsp_example_3.txt.tour
	|-- tsp_example_4.txt.tour
	|-- tsp_example_5.txt.tour
	|-- TSPAllVisited.py
	|-- tsp-verifier.py
	|-- TSPAllVisited.pyc

4- Execute "chmod +x HW6.sh". This gives admin privileges to executable.
5- Execute "./HW6.sh".